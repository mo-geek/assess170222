class DataSet {
  int? noOfOrders;
  DateTime? date;

  DataSet(this.date, this.noOfOrders);
}
